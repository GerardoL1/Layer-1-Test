# Recovery Platform (Group 2)

Turns Apple Watch data into a general readiness score and muscle-specific fatigue scores, with plain-language explanations.

This repo currently holds the **Layer 1 test**: proving that data can travel the full path.

```
Apple Watch → iPhone Health app → mobile app → server → computer browser
```

| Folder | What it is |
|---|---|
| `mobile/` | Expo / React Native (TypeScript) iPhone app. Reads heart rate, resting heart rate and HRV from Apple Health and sends them to the server. |
| `server/` | Python FastAPI server. Stores uploads in SQLite and shows a chart at `http://localhost:8000`. |

A computer can't read Apple Health data directly, so the iPhone app is always the collector. The computer only views data from the server.

## Requirements

- Mac with Xcode (needed to build the iPhone app)
- iPhone paired with an Apple Watch that has been worn for a few hours
- Node.js 20+ and Python 3.10+
- Mac and iPhone on the same Wi-Fi

## 1. Start the server

```bash
cd server
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

Find the Mac's IP with `ipconfig getifaddr en0`. From the iPhone's Safari, open `http://<IP>:8000/health`; you should see `{"ok":true}`.

## 2. Build the iPhone app

```bash
cd mobile
npm install
npx expo run:ios --device
```

Before the first build:
- In `mobile/app.json`, change `ios.bundleIdentifier` (`com.group2.recoverytest`) to something unique to your team.
- On the iPhone, turn on Settings → Privacy & Security → Developer Mode.
- Sign in with your Apple ID in Xcode → Settings → Accounts if asked. Free accounts work, but the app expires after 7 days.
- If the phone blocks the app on first launch, trust it in Settings → General → VPN & Device Management.

The app does **not** run in Expo Go because HealthKit needs a development build.

## 3. Run the test

1. In the app, enter the server address (e.g. `http://192.168.1.50:8000`) and a tester name.
2. Tap **Connect Apple Health** and allow all three data types. Allow the local network prompt too.
3. Tap **Send to platform**.
4. On the Mac, open `http://localhost:8000` to see the chart and summary.
5. Compare a few readings with Health → Heart → Heart Rate. Tap Send again; it should report **0 new** (duplicates are ignored).

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| 0 samples read | Permissions off: Settings → Health → Data Access & Devices → Recovery Test |
| "Network request failed" | Wrong IP, server not running, different Wi-Fi, or Mac firewall |
| Crash when sending | Send was tapped before Connect Apple Health |
| Only a few HRV samples | Normal; the watch measures HRV only a few times per day |

## Test-only settings to remove before real users

- `NSAllowsArbitraryLoads` in `mobile/app.json` (allows plain `http`). Real deployments need HTTPS.
- Open CORS (`allow_origins=["*"]`) in `server/main.py`.
- No login yet: the tester name is trusted as-is.

`*.db` files are git-ignored because they contain real health data. Never commit them.

## Next steps

- Local SQLite buffer on the phone with anchored (incremental) sync
- User accounts and login
- Workout log and daily readiness / soreness self-reports (training labels)
- EMG and GSR sensors over Bluetooth (ESP32)
