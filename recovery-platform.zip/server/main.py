"""
Test server for the recovery platform.

Phone app  --POST /upload-->  this server  --GET /-->  computer browser

Run:
    pip install fastapi uvicorn
    uvicorn main:app --host 0.0.0.0 --port 8000
"""
import sqlite3
from datetime import datetime, timedelta, timezone

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

DB_PATH = "platform.db"

app = FastAPI(title="Recovery platform (test)")

# Wide open for testing only, so a web version of the app can call this too.
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


with db() as conn:
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS samples (
            uuid     TEXT PRIMARY KEY,   -- HealthKit's ID, so re-sending never duplicates
            user_id  TEXT NOT NULL,
            metric   TEXT NOT NULL,      -- heart_rate, resting_heart_rate, hrv_sdnn
            value    REAL NOT NULL,
            unit     TEXT NOT NULL,
            start_ms INTEGER NOT NULL,   -- UTC milliseconds
            end_ms   INTEGER NOT NULL,
            source   TEXT                -- e.g. "Alex's Apple Watch"
        )
        """
    )


class Sample(BaseModel):
    uuid: str
    metric: str
    value: float
    unit: str
    start_ms: int
    end_ms: int
    source: str | None = None


class Upload(BaseModel):
    user_id: str
    samples: list[Sample]


@app.get("/health")
def health():
    """Open this from the phone's browser to check it can reach the server."""
    return {"ok": True}


@app.post("/upload")
def upload(payload: Upload):
    with db() as conn:
        before = conn.total_changes
        conn.executemany(
            "INSERT OR IGNORE INTO samples VALUES (?,?,?,?,?,?,?,?)",
            [
                (s.uuid, payload.user_id, s.metric, s.value, s.unit, s.start_ms, s.end_ms, s.source)
                for s in payload.samples
            ],
        )
        added = conn.total_changes - before
    print(f"[upload] {payload.user_id}: received {len(payload.samples)}, new {added}")
    return {"received": len(payload.samples), "new": added}


@app.get("/api/samples")
def get_samples(metric: str = "heart_rate", hours: int = 24, user_id: str | None = None):
    since = int((datetime.now(timezone.utc) - timedelta(hours=hours)).timestamp() * 1000)
    query = "SELECT * FROM samples WHERE metric = ? AND start_ms >= ?"
    args: list = [metric, since]
    if user_id:
        query += " AND user_id = ?"
        args.append(user_id)
    with db() as conn:
        rows = conn.execute(query + " ORDER BY start_ms", args).fetchall()
    return [dict(r) for r in rows]


@app.get("/api/summary")
def summary():
    with db() as conn:
        rows = conn.execute(
            """SELECT user_id, metric, COUNT(*) AS n, ROUND(AVG(value), 1) AS avg,
                      MIN(start_ms) AS first_ms, MAX(start_ms) AS last_ms
               FROM samples GROUP BY user_id, metric ORDER BY user_id, metric"""
        ).fetchall()
    return [dict(r) for r in rows]


@app.get("/", response_class=HTMLResponse)
def dashboard():
    return DASHBOARD_HTML


DASHBOARD_HTML = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Recovery platform — test view</title>
<style>
  :root { --ink:#1d2433; --muted:#5b6475; --line:#d9dde5; --bg:#f7f8fa; --pulse:#c2364b; }
  body { margin:0; font:15px/1.5 system-ui, -apple-system, "Segoe UI", sans-serif; color:var(--ink); background:var(--bg); }
  main { max-width:900px; margin:0 auto; padding:24px 16px 48px; }
  h1 { font-size:22px; margin:0 0 4px; }
  p.lead { color:var(--muted); margin:0 0 20px; }
  .controls { display:flex; gap:12px; flex-wrap:wrap; align-items:center; margin-bottom:16px; }
  select, button { font:inherit; padding:6px 10px; border:1px solid var(--line); border-radius:6px; background:#fff; }
  button { cursor:pointer; }
  .chart { background:#fff; border:1px solid var(--line); border-radius:8px; padding:12px; }
  svg { width:100%; height:260px; display:block; }
  .empty { color:var(--muted); padding:40px 0; text-align:center; }
  .table-wrap { overflow-x:auto; margin-top:20px; }
  table { border-collapse:collapse; width:100%; background:#fff; border:1px solid var(--line); }
  th, td { text-align:left; padding:6px 10px; border-bottom:1px solid var(--line); white-space:nowrap; }
  th { font-weight:600; color:var(--muted); font-size:13px; }
</style>
</head>
<body>
<main>
  <h1>Watch data received by the platform</h1>
  <p class="lead">This page reads from the server, not the watch. Send data from the phone app, then refresh.</p>

  <div class="controls">
    <label>Metric
      <select id="metric">
        <option value="heart_rate">Heart rate</option>
        <option value="resting_heart_rate">Resting heart rate</option>
        <option value="hrv_sdnn">HRV (SDNN)</option>
      </select>
    </label>
    <label>Last
      <select id="hours">
        <option value="24">24 hours</option>
        <option value="168">7 days</option>
        <option value="720">30 days</option>
      </select>
    </label>
    <button id="refresh">Refresh</button>
    <span id="count"></span>
  </div>

  <div class="chart" id="chart"></div>

  <div class="table-wrap">
    <table>
      <thead><tr><th>User</th><th>Metric</th><th>Samples</th><th>Average</th><th>First</th><th>Latest</th></tr></thead>
      <tbody id="summary"></tbody>
    </table>
  </div>
</main>
<script>
const $ = (id) => document.getElementById(id);
const fmt = (ms) => new Date(ms).toLocaleString();

async function load() {
  const metric = $("metric").value, hours = $("hours").value;
  const rows = await (await fetch(`/api/samples?metric=${metric}&hours=${hours}`)).json();
  $("count").textContent = rows.length + " samples";
  drawChart(rows);
  const sum = await (await fetch("/api/summary")).json();
  $("summary").innerHTML = sum.length
    ? sum.map(r => `<tr><td>${r.user_id}</td><td>${r.metric}</td><td>${r.n}</td><td>${r.avg}</td><td>${fmt(r.first_ms)}</td><td>${fmt(r.last_ms)}</td></tr>`).join("")
    : `<tr><td colspan="6">No data yet. Tap "Send to platform" in the phone app.</td></tr>`;
}

function drawChart(rows) {
  if (!rows.length) { $("chart").innerHTML = '<div class="empty">No samples in this time range.</div>'; return; }
  const W = 860, H = 260, P = 36;
  const xs = rows.map(r => r.start_ms), ys = rows.map(r => r.value);
  const x0 = Math.min(...xs), x1 = Math.max(...xs) || x0 + 1;
  const y0 = Math.floor(Math.min(...ys) - 5), y1 = Math.ceil(Math.max(...ys) + 5);
  const sx = (v) => P + (v - x0) / Math.max(x1 - x0, 1) * (W - 2 * P);
  const sy = (v) => H - P - (v - y0) / Math.max(y1 - y0, 1) * (H - 2 * P);
  const pts = rows.map(r => `${sx(r.start_ms).toFixed(1)},${sy(r.value).toFixed(1)}`).join(" ");
  const dots = rows.length < 300 ? rows.map(r => `<circle cx="${sx(r.start_ms)}" cy="${sy(r.value)}" r="2.5" fill="var(--pulse)"/>`).join("") : "";
  $("chart").innerHTML = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Line chart of ${$("metric").value}">
    <line x1="${P}" y1="${H-P}" x2="${W-P}" y2="${H-P}" stroke="var(--line)"/>
    <text x="4" y="${sy(y1)+4}" font-size="11" fill="var(--muted)">${y1}</text>
    <text x="4" y="${sy(y0)+4}" font-size="11" fill="var(--muted)">${y0}</text>
    <text x="${P}" y="${H-12}" font-size="11" fill="var(--muted)">${fmt(x0)}</text>
    <text x="${W-P}" y="${H-12}" font-size="11" fill="var(--muted)" text-anchor="end">${fmt(x1)}</text>
    <polyline points="${pts}" fill="none" stroke="var(--pulse)" stroke-width="1.5"/>${dots}</svg>`;
}

$("refresh").onclick = load; $("metric").onchange = load; $("hours").onchange = load;
load();
</script>
</body>
</html>"""
